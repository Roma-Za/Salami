var DEFAULT_USER_PICTURE = 'img/default_user_picture.png';
